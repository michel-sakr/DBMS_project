# DBMS_Project_2020
 Database Managment Systems Final Project - Fall 2020
 
This project stores a database for an NGO (non-governmental organization) regrouping data about the victims and damages following the 4th of August explosion in Beirut.
The website offers a helping hand to the victims of the horrible event that took place in the heart of Beirut, as well as an opportunity for people searching for ways to help. The data will be used to extract new and useful information that cannot be acquired by simple data collection. In addition, the collected data will help provide benefactors and contributors with insight on the areas where help is most needed (both how to help, and who to help). Finally, the interaction this website provides is expected to lead to a more efficient and organized help process and faster progress and better coverage of needs.
